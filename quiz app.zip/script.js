 
 
     //  questins set
 
 var questions = [           

     { num : 1 , question : " What does HTML stands?" ,  
     answer : "Hyper Text Markup Language" , options : [ "Hyper Text Markup Language" , "Holistick Technical Method Library" , "Hyper Tax Makes Line" , "None of the above" ]  } ,

     { num : 2 , question : " Which of the following CSS selectors are used to specify a group of elements?" , answer : "class" , options : [ "tag" , "id" , "class" , "both class and tag"     ]  } , 


     { num : 3 , question : " Which of the following has introduced text, list, box, margin, border, color, and background properties?" , answer : "CSS" , options : [ "HTML" , "PHP" , "AJAX" , "CSS"     ]  } ,

     { num : 4 , question : " Which of the following CSS framework is used to create a responsive design?" , answer : "Bootstrap" , options : [ "Rails" , "Bootstrap" , "Django" , "Larawell"     ]  } ,

     { num : 5 , question : " Which of the following CSS selector is used to specify a rule to bind a particular unique element?" , answer : "Id" , options : [ "Tags" , "Class" , "Both C & D" , "Id"     ]  } ,

     { num : 6  , question : " Which of the following CSS property is used to make the text bold?" , answer : "font-weight: bold" , options : [ "text-decoration: bold" , "font-weight: bold" , "font-style: bold" , "text-align: bold"     ]  } ,



     { num : 7  , question : " Which of the following CSS property sets the font size of text?" , answer : "font-size" , options : [ "font-size" , "text-size" , "text" , "size"     ]  } ,


     { num : 8  , question : " Which of the following is not the property of the CSS box model?" , answer : "color" , options : [ "margin" , "color" , "width" , "height" ]  } ,

 ];


 
 
 
    
      // html targeted by DOM
 
    const start_btn  = document.querySelector(".start-quiz") ;

    const quiz_box  = document.querySelector(".quiz-box") ;

   const question_text  = document.querySelector(".question-text") ;
    
   const options_box = quiz_box.querySelector(".options") ;

   const next_btn = document.querySelector(".next-btn") ;

   const mark_correct = '<i class="material-icons">done</i>' 

   const mark_wrong  = '<i class="material-icons">clear</i>'

   const total_q = document.querySelector(".quiz-footer .total_q ")

   const quest_count = document.querySelector(".quiz-footer .quest_count ")
   const result_box = document.querySelector(".result-box")
   const Total_q_r = document.querySelector(".total-quest span ")
   const right_quest = document.querySelector(".right-quest span ")
   const wrong_quest = document.querySelector(".wrong-quest span ")
   const percentage = document.querySelector(".percentage  span ")
   const Again_quiz = document.querySelector(".result-footer .Again-quiz")
   const exit = document.querySelector(".result-footer .exit")




  

  

    // start_btn function

    start_btn.onclick =()=>{

    quiz_box.classList.remove("inactive");
    
    start_btn.classList.add("inactive") ;}

  
  


    // questions showing
  
    total_q.innerText = questions.length

   Total_q_r.innerText = questions.length



   quest_index = 0;

  var right_answers = 0
  var wrong_answers = 0


  quest_count.innerText = quest_index +1

  showQuestion(quest_index) ;

  // quiz_box dynamycally by js

 function showQuestion(q_index){   


  question_text.innerHTML = questions[q_index].num + "."+ questions[q_index].question ;

  var option_statement = "" ;
 for( var i = 0 ; i < questions[0].options.length ; i++)
    {  option_statement += `<div class="option">${questions[q_index].options[i]} </div>`};




  options_box.innerHTML =  option_statement ;

  var AllOptions = options_box.querySelectorAll(".option") ;
  for( var j = 0; j< AllOptions.length ; j++)
  { AllOptions[j].setAttribute("onclick", "UserAnswer(this)") ; }

  next_btn.classList.add("inactive")
   
 
 };


  //  next_btn function

 next_btn.onclick=()=>{

  quest_index++ ;

  if(questions.length>quest_index){
    
  quest_count.innerText=quest_index +1
  showQuestion(quest_index)
    }else{
    console.log("complete")  
  
    quiz_box.classList.add("inactive")
    
    result_box.classList.remove("inactive")

    right_quest.innerText = right_answers

    wrong_quest.innerText = wrong_answers  

    percentage.innerText = (( right_answers*100)/questions.length).toFixed(2)+"%" 


    
  }

 if(questions.length-1 == quest_index){next_btn.innerText= "Finish"}


}


//  user input

function UserAnswer(answer){
  
  let userAns = answer.innerText;
  
  let correctAns = questions[quest_index].answer
  var AllOptions2 = options_box.querySelectorAll(".option") ;
   next_btn.classList.remove("inactive")


 if( userAns==correctAns )
{console.log("right") 

answer.classList.add("correct") ;
answer.insertAdjacentHTML("beforeend" , mark_correct )
right_answers++
}
else{ console.log("wrong")
answer.classList.add("wrong")
wrong_answers++

answer.insertAdjacentHTML("beforeend" , mark_wrong )

for(var i= 0 ; i < AllOptions2.length ; i++ ){

if( AllOptions2[i].innerText==correctAns ){

 AllOptions2[i].classList.add("correct")
 AllOptions2[i].insertAdjacentHTML("beforeend", mark_correct )
}}}


for( var j = 0; j< AllOptions2.length ; j++)
{ AllOptions2[j].classList.add("disabled"); }

};
  

// Again_quiz btn
  Again_quiz.onclick=()=>{

  quiz_box.classList.remove("inactive")
  result_box.classList.add("inactive")

  reset();
  }


  // exit btn

  exit.onclick=()=>{   

    start_btn.classList.remove("inactive")
   result_box.classList.add("inactive");
 
   reset()
    
  }

  function reset(){

    quest_index = 0;

    right_answers = 0
    wrong_answers = 0
 
 
   quest_count.innerText = quest_index +1
 
   showQuestion(quest_index) ;
 
   next_btn.innerText="Next Question"}










 
  
  
    